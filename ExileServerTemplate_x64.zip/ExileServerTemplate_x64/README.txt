- This is a vanilla template for EXILE servers
- This include a basic for build EXILE in too
- compositions contain a composition for icons, zones, traders and 100 player slots
- modTools contain a important mods for development
- infistar admin & antihaks tools in, mission, server and dll files
- GoldbergSteamEmulator files:
  - experimental_steamclient_ExileServerTemplate
    - steamclient.dll
    - steamclient64.dll
    - steamclient_loader.exe
    - ColdClientLoader.ini
  - steam_api.dll
  - steam_api64.dll
  - !Start_ExileServerTemplate.bat
- modify commandline in experimental_steamclient_ExileServerTemplate\ColdClientLoader.ini

by Gupo de Desarrollo ArmA3 Cuba