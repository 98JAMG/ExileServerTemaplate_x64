name		 = "Loot Position Editor";								// Name of your mod
picture 	 = "\lootpositioneditor\images\logo\preview.paa"; 	// Picture displayed from the expansions menu. Optimal size is 2048x1024
logoSmall	 = "\lootpositioneditor\images\logo\logo_small.paa";	// Display next to the item added by the mod
logo		 = "\lootpositioneditor\images\logo\logo.paa";			// Logo displayed in the main menu
logoOver	 = "\lootpositioneditor\images\logo\logo_active.paa";		// When the mouse is over, in the main menu
actionName   = "Website";                    // name of the action button
action		 = "https://hellbz.de";			// Website URL, that can accessed from the expansions menu
tooltipOwned = "Loot Position Editor Owned";								// Tool tip displayed when the mouse is left over, in the main menu
description = "Coming Soon";

overviewFootnote = "Coming Soon";

// Color used for DLC stripes and backgrounds (RGBA)
dlcColor[] =
{
	0.23,
	0.39,
	0.30,
	1
};
// Overview text, displayed from the extension menu
overview = "With this tool loot positions can be generist, set or also imported and afterwards edited or completely deleted, besides everything can be exported as a file, this works in the 32 and 64 bit variant. Big thanks goes to Patrix87, because source is from him.";
hideName	= 0;	// Hide the extension name
hidePicture	= 0;	// Hide the extension menu

author = "HellBz";     // author?