protocol = 1;
publishedid = 0;
name = "Loot Position Editor";
timestamp = 5249267983515981711;
